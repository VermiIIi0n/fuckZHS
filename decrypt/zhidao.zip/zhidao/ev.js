k = "zzpttjd";
function X(t) {
    for (var e = "", i = 0; i < t.length; i++) {
        var n = t.charCodeAt(i) ^ k.charCodeAt(i % k.length);
        e += Y(n)
    }
    return e
}
function Y(t) {
    var e = t.toString(16);
    e = e.length < 2 ? 0 + e : e;
    return e.slice(-4)
}
function Z(t) {
    for (var e = "", i = 0; i < t.length; i++) {
        e += t[i] + ";";
    }
    e = e.substring(0, e.length - 1);
    return X(e);
}
console.log(Z([1,2,3,4,'你']))